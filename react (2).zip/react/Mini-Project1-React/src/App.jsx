
import Card from './Card'

export default function App(){


  return (

    <div>
      <Card />
    </div>
  )

}

